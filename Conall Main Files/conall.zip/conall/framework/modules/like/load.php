<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/like/like.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/like/like-functions.php';