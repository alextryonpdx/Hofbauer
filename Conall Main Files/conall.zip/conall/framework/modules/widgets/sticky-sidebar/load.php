<?php

require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/widgets/sticky-sidebar/sticky-sidebar.php';
