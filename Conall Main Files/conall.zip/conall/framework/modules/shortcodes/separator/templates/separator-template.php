<div class="edgtf-separator-holder clearfix  <?php echo esc_attr($separator_class); ?>">
	<div class="edgtf-separator" <?php echo conall_edge_get_inline_style($separator_style); ?>></div>
</div>
