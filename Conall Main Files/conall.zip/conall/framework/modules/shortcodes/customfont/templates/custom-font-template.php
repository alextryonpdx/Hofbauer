<<?php echo esc_attr($custom_font_tag);?> class="edgtf-custom-font-holder" <?php conall_edge_inline_style($custom_font_style); echo esc_attr($custom_font_data);?>>
	<span class="edgtf-custom-font-original"><?php echo esc_html($content_custom_font); ?></span>
</<?php echo esc_attr($custom_font_tag);?>>