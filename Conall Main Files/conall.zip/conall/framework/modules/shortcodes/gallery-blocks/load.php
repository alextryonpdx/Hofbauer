<?php

require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/gallery-blocks/gallery-block.php';
require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/gallery-blocks/gallery-block-left-item.php';
require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/gallery-blocks/gallery-block-right-item.php';