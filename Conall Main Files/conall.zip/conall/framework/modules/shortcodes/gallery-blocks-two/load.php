<?php

require_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/gallery-blocks-two/gallery-block.php';