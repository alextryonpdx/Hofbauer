<div class="edgtf-social-share-holder edgtf-list">
	<ul>
		<?php foreach ($networks as $net) {
			print $net;
		} ?>
	</ul>
</div>