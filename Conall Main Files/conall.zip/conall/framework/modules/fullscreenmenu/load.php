<?php

include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/fullscreenmenu/options-map/map.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/fullscreenmenu/fullscreen-menu-functions.php';
include_once EDGE_FRAMEWORK_MODULES_ROOT_DIR.'/fullscreenmenu/custom-styles/fullscreen-menu.php';