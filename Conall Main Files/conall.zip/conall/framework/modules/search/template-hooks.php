<?php

//Get search HTML
add_action('conall_edge_before_page_header', 'conall_edge_get_search', 9);