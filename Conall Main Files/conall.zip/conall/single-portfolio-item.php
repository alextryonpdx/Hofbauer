<?php

get_header();
conall_edge_get_title();
get_template_part('slider');
conall_edge_single_portfolio();
get_footer();

?>